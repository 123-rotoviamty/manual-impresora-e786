/*
 * script.js
 *
 * Este archivo contiene la lógica necesaria para manejar los flujos
 * interactivos del manual. Define los pasos para cada proceso y
 * actualiza dinámicamente el contenido de la página cuando el
 * usuario selecciona una opción del menú o navega entre pasos.
 */

// Definición de los flujos y sus pasos. Cada paso contiene un
// título, una descripción y la ruta de la imagen asociada.
const flows = {
    copiar: [
        {
            title: 'Colocar el documento',
            description: 'Abra la tapa del escáner o coloque el original en el alimentador automático (ADF). Alinee los bordes con las marcas de guía.',
            image: 'img/step-01.jpg'
        },
        {
            title: 'Seleccionar la función Copiar',
            description: 'En el panel táctil seleccione “Copiar”. Ajuste las opciones como número de copias, tamaño y color.',
            image: 'img/step-01.jpg'
        },
        {
            title: 'Iniciar la copia',
            description: 'Pulse el botón de inicio. Retire sus copias de la bandeja de salida cuando finalice.',
            image: 'img/step-01.jpg'
        }
    ],
    escanear: [
        {
            title: 'Preparar el original',
            description: 'Coloque el documento o la foto sobre el cristal o en el alimentador automático.',
            image: 'img/step-02.jpg'
        },
        {
            title: 'Escoger Escanear',
            description: 'En el panel táctil pulse “Escanear” y seleccione el destino (correo electrónico, carpeta de red o USB).',
            image: 'img/step-02.jpg'
        },
        {
            title: 'Configurar y escanear',
            description: 'Ajuste el tipo de archivo (PDF/JPEG) y la resolución. Pulse inicio para escanear y compruebe el archivo en el destino seleccionado.',
            image: 'img/step-02.jpg'
        }
    ],
    imprimir: [
        {
            title: 'Enviar el trabajo desde su computadora',
            description: 'Abra el documento o la imagen y seleccione “Imprimir” en la aplicación. Elija la impresora HP Color LaserJet Managed MFP E786 en la lista.',
            image: 'img/step-03.jpg'
        },
        {
            title: 'Ajustar la configuración',
            description: 'Configure el número de copias, tamaño de papel, color y cualquier otra preferencia en el cuadro de diálogo de impresión.',
            image: 'img/step-03.jpg'
        },
        {
            title: 'Confirmar impresión',
            description: 'Pulse “Imprimir”. Diríjase a la impresora y recoja las hojas en la bandeja de salida.',
            image: 'img/step-03.jpg'
        }
    ],
    atasco: [
        {
            title: 'Detener y abrir la puerta',
            description: 'Cuando el panel indique un atasco de papel, abra la puerta derecha o la puerta de acceso al fusor según lo indique la pantalla.',
            image: 'img/step-04.jpg'
        },
        {
            title: 'Retirar el papel atascado',
            description: 'Retire con cuidado el papel atascado sujetándolo con ambas manos. Tire suavemente para evitar que se rompa.',
            image: 'img/step-04.jpg'
        },
        {
            title: 'Cerrar y reanudar',
            description: 'Cierre la puerta firmemente y siga las instrucciones del panel para continuar con su trabajo.',
            image: 'img/step-04.jpg'
        }
    ],
    toner: [
        {
            title: 'Abrir la cubierta frontal',
            description: 'Apague la impresora si es necesario y abra la cubierta frontal para acceder al cartucho de tóner.',
            image: 'img/step-05.jpg'
        },
        {
            title: 'Extraer el cartucho usado',
            description: 'Tire del asa del cartucho hacia usted y retírelo completamente de la impresora.',
            image: 'img/step-05.jpg'
        },
        {
            title: 'Preparar el nuevo cartucho',
            description: 'Desembale el cartucho nuevo. Agítelo suavemente de lado a lado para distribuir el tóner en su interior.',
            image: 'img/step-05.jpg'
        },
        {
            title: 'Insertar y cerrar',
            description: 'Introduzca el cartucho nuevo hasta que encaje. Cierre la cubierta frontal y espere a que la impresora se inicialice.',
            image: 'img/step-05.jpg'
        }
    ]
};

// Títulos legibles para cada flujo
const titles = {
    copiar: 'Flujo de copiado',
    escanear: 'Flujo de escaneo',
    imprimir: 'Flujo de impresión',
    atasco: 'Solución de atascos',
    toner: 'Sustitución del tóner'
};

let currentFlow = null;
let currentStepIndex = 0;

/**
 * Muestra el flujo seleccionado e inicializa el índice de paso.
 * @param {string} flowName - Nombre de la clave en el objeto flows.
 */
function showFlow(flowName) {
    if (!flows[flowName]) return;
    currentFlow = flows[flowName];
    currentStepIndex = 0;
    // Actualizar el título del flujo
    document.getElementById('flow-title').textContent = titles[flowName];
    document.getElementById('flow-container').classList.remove('hidden');
    updateStep();
    // Desplazar la vista al inicio del contenedor de pasos
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Actualiza el contenido de la página con el paso actual.
 */
function updateStep() {
    if (!currentFlow) return;
    const step = currentFlow[currentStepIndex];
    document.getElementById('step-title').textContent = step.title;
    document.getElementById('step-description').textContent = step.description;
    document.getElementById('step-image').src = step.image;
    // Deshabilitar botones al inicio o final
    document.getElementById('prevBtn').disabled = currentStepIndex === 0;
    document.getElementById('nextBtn').disabled = currentStepIndex === currentFlow.length - 1;
}

/**
 * Avanza al siguiente paso del flujo, si existe.
 */
function nextStep() {
    if (!currentFlow) return;
    if (currentStepIndex < currentFlow.length - 1) {
        currentStepIndex++;
        updateStep();
    }
}

/**
 * Retrocede al paso anterior del flujo, si existe.
 */
function prevStep() {
    if (!currentFlow) return;
    if (currentStepIndex > 0) {
        currentStepIndex--;
        updateStep();
    }
}