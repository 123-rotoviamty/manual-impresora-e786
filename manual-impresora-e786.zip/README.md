# Manual interactivo de la HP Color LaserJet Managed MFP E786

Este repositorio contiene una guía web estática para los principales procesos de la impresora **HP Color LaserJet Managed MFP E786**, incluidos copiar, escanear, imprimir, solución de atascos y sustitución del tóner. Al escanear un código QR o abrir el archivo `index.html`, los usuarios podrán seguir pasos visuales que imitan el panel real.

## Estructura del proyecto

```
manual-impresora-e786/
├── index.html        ← Página principal del manual
├── style.css         ← Hoja de estilos con diseño responsive (hasta 850 px)
├── script.js         ← Lógica de navegación paso a paso sin frameworks
├── img/              ← Carpeta de imágenes (ordenadas como step-01.jpg…)
├── sources.txt       ← Enlaces a las páginas oficiales consultadas
└── README.md         ← Este documento de ayuda y despliegue
```

### Uso local

Para abrir la guía sin conexión a internet basta con **hacer doble clic en `index.html`**. Todos los recursos (CSS, JavaScript e imágenes) están incluidos localmente.

## Despliegue en GitHub Pages

1. Crea un repositorio en GitHub, por ejemplo `manual-impresora-e786`.
2. Sube el contenido de esta carpeta al repositorio (puedes arrastrar y soltar los archivos mediante la interfaz web o usar Git desde la línea de comandos).
3. Ve a la configuración del repositorio (`Settings → Pages`). En **“Source”** selecciona la rama principal (`main` o `master`) y la carpeta raíz (`/`). Guarda los cambios.
4. GitHub generará una URL del tipo `https://tuusuario.github.io/manual-impresora-e786/`. Esta URL utiliza **HTTPS** de forma predeterminada.

## Despliegue con Netlify Drop

Si prefieres un método sencillo sin usar Git:

1. Abre [https://app.netlify.com/drop](https://app.netlify.com/drop) en tu navegador.
2. Arrastra y suelta la carpeta `manual-impresora-e786` completa o su archivo ZIP sobre la zona de carga.
3. Netlify desplegará automáticamente el sitio y te mostrará una URL segura `https://<nombre-asignado>.netlify.app/`.

Ambos métodos funcionan como hosting estático y no requieren servidores adicionales ni bases de datos.

## Seguridad

El manual está pensado para uso informativo. Procura no compartir información sensible al utilizar la impresora (como documentos confidenciales). Cuando despliegues en servicios externos asegúrate de que la URL es **HTTPS** para proteger la comunicación y de no incluir contraseñas ni datos privados en los archivos.

## Modificaciones y mantenimiento

Si en el futuro necesitas **modificar** o ampliar el manual:

- **Actualizar pasos o textos:** edita el archivo `script.js` modificando los objetos dentro de `flows`. Cada flujo contiene un array de pasos con `title`, `description` e `image`. Mantén la coherencia en la longitud y el orden.
- **Cambiar imágenes:** sustituye los archivos en la carpeta `img/` por nuevas imágenes con el mismo nombre (`step-01.jpg`, `step-02.jpg`, etc.). Si agregas pasos adicionales, guarda las nuevas imágenes en formato JPG en `img/` y referencia su ruta en el flujo correspondiente.
- **Apariencia:** puedes ajustar colores, tamaños y disposición modificando `style.css`. El diseño utiliza un máximo de 850 px de ancho para facilitar su visualización en dispositivos móviles.
- **Nuevos flujos:** crea una nueva clave dentro del objeto `flows` con un nombre descriptivo, añade el título en el objeto `titles` y suma un botón en el menú de `index.html`. El script manejará automáticamente la navegación.

Antes de publicar modificaciones, revisa el manual en modo offline para asegurarte de que las rutas a imágenes y archivos siguen siendo correctas.